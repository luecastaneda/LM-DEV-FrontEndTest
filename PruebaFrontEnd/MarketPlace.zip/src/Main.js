import React, { Component } from "react";
import {Button} from 'react-bootstrap';
import './Main.css';
// import {
//   Route,
//   NavLink,
//   HashRouter
// } from "react-router-dom";

 
class Main extends Component {
  state = { empresa: '',
            product: '',
            descount: '',
            moneda: ''};


            register(){
              const {
                empresa,
                product,
                descount,
                moneda
              } = this.state;
              let validate = false;
              
              this.setState({
                  nEmpresa : empresa,
                  nProduct : product,
                  descuento : descount,
                  moneda : moneda
                } );

               ///Validacion de datos
              //  const url = "url servicio";
              //  axios({
              //    method: 'POST',
              //    url,
              //    headers: {
              //      Accept: 'application/json',
              //      ['Content-Type']: 'application/json'
              //    }, 
              //    data: {
              //      user: value, // This is the body part
              //      password: this.encrypt(valuePass),
              //  }
              // }) 
          }
  render() {
    
    return (
      //<HashRouter>
      
          <form onSubmit={this.handleSubmit}>
          <h1>MARKET PLACE</h1>
          <label for="nya">Nombre de la empresa:</label>
          <input type="text" value={this.state.empresa} onChange={event => this.setState({ empresa: event.target.value })} placeholder="" required />

          <label for="product">Nombre del producto:</label>
          <input type="text" value={this.state.product} onChange={event => this.setState({ product: event.target.value })} placeholder="" required />
          
          <label for="descProduct">Descripcion del producto:</label>
          <input type="text" value={this.state.descount} onChange={event => this.setState({ descount: event.target.value })} placeholder="" required />
          
          <label for="moneda">Moneda:</label>
          <input type="text" value={this.state.moneda} onChange={event => this.setState({ moneda: event.target.value })}  placeholder="" required />

          <Button  id="Registrar" onClick = {this.register} >Registrar</Button>
          {/* <Button color="danger" id="SignIn"  onClick = {this.sayHello}>Sign In</Button> */}
          </form>
          
    
    );
  }
}
 
export default Main;